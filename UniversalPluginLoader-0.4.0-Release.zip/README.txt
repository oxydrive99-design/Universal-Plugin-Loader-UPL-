Universal Plugin Loader 0.4.0
for Scrap Mechanic

RECOMMENDED INSTALLATION
------------------------
1. Close Scrap Mechanic.
2. Run:
   UniversalPluginLoader-Installer-0.4.0.exe
3. Start Scrap Mechanic.

The installer:
- finds the Scrap Mechanic\Release folder in common Steam library locations;
- preserves the original Microsoft runtime as:
    vcruntime140_1_.dll
- installs Universal Plugin Loader as:
    vcruntime140_1.dll
- keeps an existing vcruntime140_1_.dll backup untouched.

If automatic detection fails:
- move UniversalPluginLoader-Installer-0.4.0.exe into:
    Scrap Mechanic\Release\
- run it again.

MANUAL INSTALLATION
-------------------
1. Close Scrap Mechanic.
2. Open:
   Scrap Mechanic\Release\
3. Rename the original:
   vcruntime140_1.dll
   to:
   vcruntime140_1_.dll
4. Copy the included loader:
   vcruntime140_1.dll
   into the same Release folder.
5. Start the game.

DO NOT DELETE vcruntime140_1_.dll.
It is the original Microsoft runtime used by the proxy loader.

HOW IT WORKS
------------
Universal Plugin Loader only loads native plugins declared by ACTIVE
Local/Workshop mods through:

  <mod>\Native\plugin.json

Native plugin DLLs stay inside their mods. Users no longer need to copy
individual mod DLLs into Release\DLLModules.

UPL 0.4.0 also exposes an active-content API used by newer mods to detect
whether their owning Workshop/Local mod is active and to safely disable
features when switching worlds.

DISABLE UPL
-----------
Launch Scrap Mechanic with:
  -noupl

Legacy alias:
  -noinject

CHECKSUMS
---------
UniversalPluginLoader-Installer-0.4.0.exe
SHA-256: 633a8b7139bad5c6c5d028e28761e761d1b3f2655a2c4bc7826d66c643796e88

vcruntime140_1.dll
SHA-256: a68636572afc86c56cc33c36e92c23955ac26a417b0e643d00018855813ac36e
