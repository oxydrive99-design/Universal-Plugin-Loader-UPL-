# Universal Plugin Loader 0.4.0

Universal Plugin Loader is a native plugin loader for **Scrap Mechanic**.

This release changes the plugin workflow so native DLLs can stay **inside Local/Workshop mods** instead of requiring users to manually copy every mod plugin into `Release\DLLModules`.

## Installation

### Recommended

1. Close Scrap Mechanic completely.
2. Run `UniversalPluginLoader-Installer-0.4.0.exe`.
3. Start the game.

The installer automatically preserves the original Microsoft runtime as `vcruntime140_1_.dll` and installs UPL as `vcruntime140_1.dll`.

If the installer cannot find the game automatically, place the EXE directly in:

`Scrap Mechanic\Release\`

and run it again.

### Manual installation

1. Close Scrap Mechanic.
2. Open `Scrap Mechanic\Release\`.
3. Rename the original `vcruntime140_1.dll` to `vcruntime140_1_.dll`.
4. Copy the included UPL `vcruntime140_1.dll` into the same folder.
5. Start the game.

**Do not delete `vcruntime140_1_.dll`.** It is the original Microsoft runtime used by the proxy loader.

## What's new in 0.4.0

- Loads native plugins only for **active** Local/Workshop mods.
- Native plugins are declared with `<mod>\Native\plugin.json`.
- Supports plugin deduplication by plugin ID.
- Keeps native DLLs mapped for process safety instead of unsafe `FreeLibrary` unloading.
- Adds active-content tracking for world/mod transitions.
- Adds the UPL API:
  - `UPL_GetApiVersion()`
  - `UPL_IsContentActive(...)`
  - `UPL_IsPluginActive(...)`
- Supports Workshop libraries across multiple Steam library folders.
- Supports `minLoaderVersion` in plugin manifests.
- Can be disabled with `-noupl`.
- `-noinject` is kept as a legacy disable alias.

## Why this update matters

Older KeybindBridge/native-mod setups used DLL Injector and manual files in `Release\DLLModules`.

Newer Workshop mods can ship their own native plugin directly inside the mod. After installing UPL once, Workshop updates can update the mod and its native plugin together.

If a mod tells you that the loading method has changed, reinstall this version of Universal Plugin Loader and restart Scrap Mechanic.

## Notes

- Windows x64 only.
- Close Scrap Mechanic before installing or replacing the loader.
- If you already have `vcruntime140_1_.dll`, the installer keeps the existing backup.
