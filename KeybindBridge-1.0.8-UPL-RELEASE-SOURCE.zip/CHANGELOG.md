# KeybindBridge 1.0.8-UPL

- Based on the user's latest Workshop Core and Flashlight depot archives.
- Fixes Flashlight standalone startup after switching worlds in the same game process.
- Native autonomous extensions are no longer permanently skipped when UPL still exposes
  the previous world's active-content state during the short log-watcher race.
- Content-bound extensions register dormant and KeybindRuntime activates them when
  `UPL_IsContentActive(contentId)` becomes true.
- Keeps the 1.0.7 per-world action lifecycle/deactivation logic.
- Fixes Flashlight `onDeactivate()` helper scope (`cleanupToggleSounds`).
- No Core dependency is required by Flashlight.
