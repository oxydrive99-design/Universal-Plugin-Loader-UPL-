KeybindBridge 1.0.8-UPL
Base mod content:
  - latest Core Workshop depot supplied by user
  - latest Flashlight Workshop depot supplied by user

Build native\KeybindBridge.sln in Visual Studio 2022:
  Configuration: Release
  Platform: x64

Copy the SAME freshly-built keybind_bridge.dll into BOTH:
  mods\KeybindBridge-Core\Native\
  mods\KeybindBridge-Flashlight\Native\

Universal Plugin Loader 0.4.0+ is required.

1.0.8 fixes the UPL/Active-UGC timing race:
autonomous extension scripts are registered dormant instead of being
permanently skipped when UPL has not yet observed the new Content ID.
