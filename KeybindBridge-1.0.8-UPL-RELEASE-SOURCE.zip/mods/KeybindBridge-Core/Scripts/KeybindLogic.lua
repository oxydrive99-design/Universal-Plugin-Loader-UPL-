local keybind = sm and sm.keybind or nil
local nativeLoaded = keybind ~= nil
print("[KeybindBridge] sm.keybind = " .. tostring(keybind))

KeybindLogic = class(nil)
-- One parent is the driver's seat and the optional second parent is a Mode
-- Controller. Both connections remain outside the vanilla seat hotbar.
KeybindLogic.maxParentCount = 2
KeybindLogic.maxChildCount = -1
-- Do not add connectionType.seated here. Scrap Mechanic treats children using
-- that connection as vanilla seat actions and maps them to hotbar keys 1-9.
KeybindLogic.connectionInput = sm.interactable.connectionType.power
    + sm.interactable.connectionType.logic
KeybindLogic.connectionOutput = sm.interactable.connectionType.logic
    + sm.interactable.connectionType.power
    + sm.interactable.connectionType.bearing
KeybindLogic.colorNormal = sm.color.new(0x2f8ee5ff)
KeybindLogic.colorHighlight = sm.color.new(0x66b5ffff)
KeybindLogic.poseWeightCount = 1

local DEFAULT_KEY = 0x46 -- F
local MODE_CONTROLLER_UUID = sm.uuid.new("9a2a8f43-6f74-4fc3-b25c-3e139b710003")
local CAPTURE_TIMEOUT_TICKS = 400
local VALID_MODES = {
    hold = true,
    toggle = true,
    pulse = true
}

-- Vanilla DigitalSign text effect. Everything effect-related is guarded with
-- pcall so a missing or changed visual effect can never disable block logic.
local KEY_LABEL_EFFECT = "Textsign - Text"
local KEY_LABEL_SHORT_NAMES = {
    [0x01] = "M1", [0x02] = "M2", [0x04] = "M3",
    [0x05] = "M4", [0x06] = "M5", [0x08] = "BKSP",
    [0x09] = "TAB", [0x0D] = "ENTER", [0x10] = "SHIFT",
    [0x11] = "CTRL", [0x12] = "ALT", [0x1B] = "ESC",
    [0x20] = "SPACE", [0x21] = "PGUP", [0x22] = "PGDN",
    [0x23] = "END", [0x24] = "HOME", [0x25] = "LEFT",
    [0x26] = "UP", [0x27] = "RIGHT", [0x28] = "DOWN",
    [0x2D] = "INS", [0x2E] = "DEL", [0x5B] = "LWIN",
    [0x5C] = "RWIN", [0xA0] = "LSHIFT", [0xA1] = "RSHIFT",
    [0xA2] = "LCTRL", [0xA3] = "RCTRL", [0xA4] = "LALT",
    [0xA5] = "RALT"
}

local function keyLabelText(key)
    if key == nil then return "-" end
    if key >= 0x30 and key <= 0x39 then return string.char(key) end
    if key >= 0x41 and key <= 0x5A then return string.char(key) end
    if key >= 0x70 and key <= 0x87 then return "F" .. tostring(key - 0x6F) end
    if KEY_LABEL_SHORT_NAMES[key] ~= nil then return KEY_LABEL_SHORT_NAMES[key] end

    if keybind ~= nil and keybind.keyName ~= nil then
        local ok, name = pcall(keybind.keyName, key)
        if ok and type(name) == "string" and name ~= "" then
            name = string.upper(name)
            if string.sub(name, 1, 6) == "MOUSE " then
                name = "M" .. string.sub(name, 7)
            end
            return string.sub(name, 1, 6)
        end
    end
    return "?"
end

local function keyLabelScale(text)
    local length = string.len(text)
    if length <= 1 then return 1.2 end
    if length == 2 then return 0.94 end
    if length == 3 then return 0.74 end
    if length == 4 then return 0.59 end
    if length == 5 then return 0.48 end
    return 0.41
end

local function cl_createKeyLabel(self)
    self.cl.keyLabel = nil
    self.cl.keyLabelText = nil

    local ok, effect = pcall(function()
        return sm.effect.createEffect(KEY_LABEL_EFFECT, self.interactable)
    end)
    if not ok or effect == nil then
        print("[KeybindBridge] Keybind Logic label unavailable: " .. tostring(effect))
        return
    end
    self.cl.keyLabel = effect
end

local function cl_updateKeyLabel(self, key)
    if self.cl == nil or self.cl.keyLabel == nil then return end
    local text = keyLabelText(key)
    if self.cl.keyLabelText == text then return end
    self.cl.keyLabelText = text

    local ok, err = pcall(function()
        local effect = self.cl.keyLabel
        if effect:isPlaying() then effect:stop() end
        effect:setParameter("TextContent", text)
        effect:setParameter("ASG", sm.vec3.new(0.0, 0.0, 0.9))
        effect:setParameter("Color", sm.color.new(0xffffffff))
        -- The text effect is vertical by default. Rotate it onto the top face.
        effect:setOffsetRotation(
            sm.quat.angleAxis(math.rad(-90), sm.vec3.new(1.0, 0.0, 0.0))
        )
        -- One block is 0.25 m high, so 0.124 sits just inside its top surface.
        effect:setOffsetPosition(sm.vec3.new(0.0, 0.142, 0.0))
        local scale = keyLabelScale(text)
        effect:setScale(sm.vec3.new(scale, scale, scale))
        effect:start()
    end)
    if not ok then
        print("[KeybindBridge] Keybind Logic label update failed: " .. tostring(err))
    end
end

local function cl_destroyKeyLabel(self)
    if self.cl == nil or self.cl.keyLabel == nil then return end
    pcall(function()
        if self.cl.keyLabel:isPlaying() then self.cl.keyLabel:stop() end
        self.cl.keyLabel:destroy()
    end)
    self.cl.keyLabel = nil
end

local function validKey(value)
    return type(value) == "number" and value >= 1 and value <= 254 and value == math.floor(value)
end

local function validMode(value)
    return type(value) == "string" and VALID_MODES[value] == true
end

local function connectedLockingInteractable(interactable, character)
    local locked = character:getLockingInteractable()
    if locked == nil then
        return nil
    end
    for _, parent in ipairs(interactable:getParents()) do
        if parent ~= nil and sm.exists(parent) and parent == locked then
            return parent
        end
    end
    return nil
end

local function modeFromController(interactable)
    for _, parent in ipairs(interactable:getParents()) do
        if parent ~= nil and sm.exists(parent) and parent.shape ~= nil
            and parent.shape.uuid == MODE_CONTROLLER_UUID then
            local value = parent.power or 0
            if value <= -0.5 then return "hold" end
            if value >= 0.5 then return "pulse" end
            return "toggle"
        end
    end
    return nil
end

local function playerInConnectedSeat(interactable, player)
    local character = player and player.character or nil
    if character == nil or not sm.exists(character) then
        return nil
    end

    return connectedLockingInteractable(interactable, character)
end

local function gameplayInputBlocked()
    if keybind ~= nil and keybind.isGameMenuOpen ~= nil
        and keybind.isGameMenuOpen() then
        return true
    end
    if sm.gui ~= nil and sm.gui.hasActiveGui ~= nil then
        local ok, active = pcall(sm.gui.hasActiveGui)
        return ok and active == true
    end
    return false
end

function KeybindLogic.server_onCreate(self)
    local saved = self.storage:load() or {}
    self.sv = {
        key = validKey(saved.key) and saved.key or DEFAULT_KEY,
        mode = validMode(saved.mode) and saved.mode or "hold",
        active = false,
        driver = nil
    }

    self.interactable:setActive(false)
    self.interactable:setPower(0)
    self:sv_syncConfiguration()
end

function KeybindLogic.server_onFixedUpdate(self)
    local controlledMode = modeFromController(self.interactable)
    if controlledMode ~= nil and controlledMode ~= self.sv.mode then
        self.sv.mode = controlledMode
        self:sv_applyState(false, nil)
        self:sv_syncConfiguration()
    end

    if not self.sv.active then
        return
    end

    if playerInConnectedSeat(self.interactable, self.sv.driver) == nil then
        self:sv_applyState(false, nil)
    end
end

function KeybindLogic.sv_syncConfiguration(self)
    self.storage:save({ key = self.sv.key, mode = self.sv.mode })
    self.network:setClientData({ key = self.sv.key, mode = self.sv.mode })
end

function KeybindLogic.sv_setBinding(self, data, player)
    if type(data) ~= "table" or not validKey(data.key) then
        return
    end

    local character = player and player.character or nil
    if character == nil or not sm.exists(character) then
        return
    end

    if (character.worldPosition - self.shape.worldPosition):length() > 5.0 then
        return
    end

    self.sv.key = data.key
    if validMode(data.mode) then
        self.sv.mode = data.mode
    end
    self:sv_applyState(false, nil)
    self:sv_syncConfiguration()
end

function KeybindLogic.sv_setMode(self, mode, player)
    self:sv_setBinding({ key = self.sv.key, mode = mode }, player)
end

function KeybindLogic.sv_requestState(self, requestedState, player)
    if type(requestedState) ~= "boolean" then
        return
    end

    if playerInConnectedSeat(self.interactable, player) == nil then
        return
    end

    self:sv_applyState(requestedState, requestedState and player or nil)
end

function KeybindLogic.sv_applyState(self, state, driver)
    if self.sv.active == state and self.sv.driver == driver then
        return
    end

    self.sv.active = state
    self.sv.driver = driver
    self.interactable:setActive(state)
    self.interactable:setPower(state and 1 or 0)
end

function KeybindLogic.client_onCreate(self)
    self.cl = {
        key = DEFAULT_KEY,
        mode = "hold",
        capturing = false,
        captureToken = nil,
        captureTicks = 0,
        lastPressSerial = keybind and keybind.pressSerial(DEFAULT_KEY) or 0,
        lastSentState = false,
        toggled = false,
        pulseTicks = 0,
        wasSeated = false,
        waitingForRelease = false,
        showedMissingDll = false
    }
    cl_createKeyLabel(self)
    cl_updateKeyLabel(self, self.cl.key)
end

function KeybindLogic.client_onDestroy(self)
    if keybind and self.cl.captureToken then
        keybind.cancelCapture(self.cl.captureToken)
    end
    cl_destroyKeyLabel(self)
end

function KeybindLogic.client_onClientDataUpdate(self, data)
    if type(data) ~= "table" then
        return
    end

    if validKey(data.key) then
        self.cl.key = data.key
        self.cl.lastPressSerial = keybind and keybind.pressSerial(data.key) or 0
        cl_updateKeyLabel(self, data.key)
    end
    if validMode(data.mode) then
        self.cl.mode = data.mode
    end

    self.cl.toggled = false
    self.cl.pulseTicks = 0
    self.cl.wasSeated = false
    self.cl.waitingForRelease = false
    self:cl_sendState(false)
end

function KeybindLogic.client_canInteract(self, character)
    if keybind then
        local modeText = self.cl.mode == "hold" and "HOLD" or string.upper(self.cl.mode)
        sm.gui.setInteractionText("", sm.gui.getKeyBinding("Use"), "Bind: " .. keybind.keyName(self.cl.key) .. " [" .. modeText .. "]")
    else
        sm.gui.setInteractionText("", sm.gui.getKeyBinding("Use"), "KeybindBridge DLL is missing")
    end
    return true
end

function KeybindLogic.client_onInteract(self, character, state)
    if not state then
        return
    end

    if not keybind then
        sm.gui.displayAlertText("KeybindBridge: install keybind_bridge.dll into Release/DLLModules", 4)
        self.cl.showedMissingDll = true
        return
    end

    self.cl.captureToken = keybind.beginCapture()
    self.cl.capturing = true
    self.cl.captureTicks = 0
    self:cl_sendState(false)
    sm.gui.displayAlertText("Press a key (Esc cancels)", 4)
end

function KeybindLogic.client_onTinker(self, character, state)
    if not state then
        return
    end

    local nextMode = "hold"
    if self.cl.mode == "hold" then
        nextMode = "toggle"
    elseif self.cl.mode == "toggle" then
        nextMode = "pulse"
    end
    self.network:sendToServer("sv_setMode", nextMode)
end

function KeybindLogic.client_canTinker(self, character)
    sm.gui.setInteractionText("", sm.gui.getKeyBinding("Tinker"), "Mode [U]: " .. string.upper(self.cl.mode))
    return true
end

function KeybindLogic.client_onFixedUpdate(self)
    self.interactable:setPoseWeight(0, self.interactable.active and 1 or 0)

    if not keybind then
        return
    end

    if self.cl.capturing then
        self.cl.captureTicks = self.cl.captureTicks + 1
        local captured = keybind.captureNext(self.cl.captureToken)
        if captured ~= nil then
            self.cl.capturing = false
            self.cl.captureToken = nil
            self.cl.captureTicks = 0

            if captured == keybind.VK.ESCAPE then
                sm.gui.displayAlertText("Key binding cancelled", 2)
            else
                self.network:sendToServer("sv_setBinding", { key = captured, mode = self.cl.mode })
                sm.gui.displayAlertText("Bound to " .. keybind.keyName(captured), 2)
            end
        elseif self.cl.captureTicks >= CAPTURE_TIMEOUT_TICKS then
            keybind.cancelCapture(self.cl.captureToken)
            self.cl.capturing = false
            self.cl.captureToken = nil
            self.cl.captureTicks = 0
            sm.gui.displayAlertText("Key binding timed out", 2)
        end
        return
    end

    local pressSerial = keybind.pressSerial(self.cl.key)
    local localPlayer = sm.localPlayer.getPlayer()
    if playerInConnectedSeat(self.interactable, localPlayer) == nil then
        -- Discard every edge produced while the player is outside the connected
        -- driver's seat. Otherwise toggle/pulse replays it after entering.
        self.cl.lastPressSerial = pressSerial
        self.cl.toggled = false
        self.cl.pulseTicks = 0
        self.cl.wasSeated = false
        self.cl.waitingForRelease = false
        self:cl_sendState(false)
        return
    end

    if not self.cl.wasSeated then
        self.cl.wasSeated = true
        self.cl.lastPressSerial = pressSerial
        self.cl.waitingForRelease = keybind.isDown(self.cl.key)
        self.cl.toggled = false
        self.cl.pulseTicks = 0
        self:cl_sendState(false)
        return
    end

    if gameplayInputBlocked() then
        -- Raw input keeps changing under inventory, containers and pause. Keep
        -- the serial synchronized and require a release before resuming so no
        -- key from the GUI is replayed into the creation.
        self.cl.lastPressSerial = pressSerial
        self.cl.waitingForRelease = keybind.isDown(self.cl.key)
        if self.cl.mode == "hold" then
            self:cl_sendState(false)
        end
        return
    end

    if self.cl.waitingForRelease then
        self.cl.lastPressSerial = pressSerial
        if not keybind.isDown(self.cl.key) then
            self.cl.waitingForRelease = false
        end
        self:cl_sendState(false)
        return
    end

    local pressed = pressSerial ~= self.cl.lastPressSerial
    self.cl.lastPressSerial = pressSerial

    if self.cl.mode == "hold" then
        self:cl_sendState(keybind.isDown(self.cl.key))
    elseif self.cl.mode == "toggle" then
        if pressed then
            self.cl.toggled = not self.cl.toggled
            self:cl_sendState(self.cl.toggled)
        end
    elseif self.cl.mode == "pulse" then
        if pressed then
            self.cl.pulseTicks = 2
            self:cl_sendState(true)
        elseif self.cl.pulseTicks > 0 then
            self.cl.pulseTicks = self.cl.pulseTicks - 1
            if self.cl.pulseTicks == 0 then
                self:cl_sendState(false)
            end
        end
    end
end

function KeybindLogic.cl_sendState(self, state)
    if self.cl.lastSentState == state then
        return
    end

    self.cl.lastSentState = state
    self.network:sendToServer("sv_requestState", state)
end
