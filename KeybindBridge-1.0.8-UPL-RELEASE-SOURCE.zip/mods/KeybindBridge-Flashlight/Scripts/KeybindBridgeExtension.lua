local CUSTOM_FLASHLIGHT_EFFECT = "KeybindBridge - Character Flashlight"
local FALLBACK_FLASHLIGHT_EFFECT = "HeadLight"
-- Vanilla effect-set names for these FMOD events:
-- {c49b6045-9381-4d39-8da2-a59d51300fce}
-- event:/vehicle/triggers/trigger_switch_on
-- {5662a157-cbc5-4a71-bceb-d0ab1a2086cb}
-- event:/vehicle/triggers/trigger_switch_off
local TOGGLE_ON_EFFECT = "Button - On"
local TOGGLE_OFF_EFFECT = "Button - Off"
-- A delayed click is worse than a missing click. Ten eligible callbacks leave
-- enough room for a transient no-world callback without building a sound tail.
local TOGGLE_SOUND_MAX_ATTEMPTS = 10
local TOGGLE_SOUND_LIFETIME_TICKS = 400
local HEAD_BONE = "jnt_head"
local FIRST_PERSON_FORWARD_OFFSET = 0.005
local FIRST_PERSON_UP_OFFSET = 0.07
local THIRD_PERSON_FORWARD_OFFSET = 0.10
local THIRD_PERSON_UP_OFFSET = 0.07
local CROUCH_FALLBACK_OFFSET = -0.45

-- ============================================================================
-- FLASHLIGHT TUNING
-- Edit only these values to change how the flashlight looks.
--
-- RANGE            = maximum useful light distance.
-- INTENSITY        = direct light power.
-- LUMINANCE        = apparent brightness of the spot light. Lower values also
--                    reduce the bright/hazy-looking beam in dark scenes.
-- CONE_ANGLE       = beam width in degrees. Smaller = narrower beam.
-- CONE_FADE        = softness of the beam edge. 0 = harder edge, 1 = very soft.
-- AMBIENT_*        = indirect fill around the player. Kept at zero on purpose
--                    so the flashlight does NOT brighten the whole area.
-- SHADOW_MODE      = 2 keeps dynamic shadows enabled.
-- ============================================================================
local FLASHLIGHT_RANGE = 25.0
local FLASHLIGHT_INTENSITY = 1.0
local FLASHLIGHT_LUMINANCE = 1.45
local FLASHLIGHT_CONE_ANGLE = 28.0
local FLASHLIGHT_CONE_FADE = 0.20

local FLASHLIGHT_AMBIENT = false
local FLASHLIGHT_AMBIENT_POSITION_SCALE = 0.0
local FLASHLIGHT_AMBIENT_INTENSITY_SCALE = 0.0
local FLASHLIGHT_AMBIENT_RANGE_SCALE = 0.0

local FLASHLIGHT_SHADOW_MODE = 2

local flashlight = {
    id = "keybindbridge.autonomous_flashlight",
    actions = {
        {
            id = "keybindbridge.flashlight.toggle",
            label = "Flashlight",
            defaultKey = "F"
        }
    },
    -- The host bone keeps the source on the character. Only its inexpensive
    -- local offsets are refreshed so the beam follows the exact camera aim.
    -- Five milliseconds is below one frame at common refresh rates while the
    -- native runtime still coalesces duplicate Lua callbacks.
    updateIntervalMs = 5,
    enabled = false,
    effect = nil,
    effectName = nil,
    hostCharacter = nil,
    started = false,
    worldErrorLogged = false,
    blocked = false,
    customEffectUnavailable = false,
    postureCharacter = nil,
    standingEyeHeight = nil,
    pendingSound = nil,
    pendingSoundAttempts = 0,
    pendingSoundErrorLogged = false,
    soundEffects = {}
}

local function trace(message)
    if sm.keybind ~= nil and sm.keybind.trace ~= nil then
        sm.keybind.trace("flashlight: " .. message)
    end
end

local function setEffectParameterSafe(effect, name, value)
    if effect == nil or effect.setParameter == nil then
        return false
    end

    local ok, errorText = pcall(effect.setParameter, effect, name, value)
    if not ok then
        trace("parameter ignored: " .. name .. " (" .. tostring(errorText) .. ")")
    end
    return ok
end

local function applyFlashlightSettings(effect)
    -- HeadLight and custom spot-light effects can expose slightly different
    -- parameter sets. Each value is therefore applied independently so an
    -- unsupported parameter can never break the flashlight.
    setEffectParameterSafe(effect, "range", FLASHLIGHT_RANGE)
    setEffectParameterSafe(effect, "intensity", FLASHLIGHT_INTENSITY)
    setEffectParameterSafe(effect, "luminance", FLASHLIGHT_LUMINANCE)
    setEffectParameterSafe(effect, "coneAngle", FLASHLIGHT_CONE_ANGLE)
    setEffectParameterSafe(effect, "coneFade", FLASHLIGHT_CONE_FADE)

    -- Kill the vanilla ambient fill / light bubble around the character.
    setEffectParameterSafe(effect, "ambient", FLASHLIGHT_AMBIENT)
    setEffectParameterSafe(effect, "ambientPosScale", FLASHLIGHT_AMBIENT_POSITION_SCALE)
    setEffectParameterSafe(effect, "ambientIntensityScale", FLASHLIGHT_AMBIENT_INTENSITY_SCALE)
    setEffectParameterSafe(effect, "ambientRangeScale", FLASHLIGHT_AMBIENT_RANGE_SCALE)

    setEffectParameterSafe(effect, "shadowMode", FLASHLIGHT_SHADOW_MODE)
end

local function destroyLight(self)
    if self.effect ~= nil and sm.exists(self.effect) then
        self.effect:destroy()
    end
    self.effect = nil
    self.effectName = nil
    self.hostCharacter = nil
    self.started = false
end

local function getAimDirection(character)
    if sm.camera ~= nil and sm.camera.getDirection ~= nil then
        local cameraDirection = sm.camera.getDirection()
        if cameraDirection ~= nil
            and cameraDirection:length2() >= 0.000001 then
            return cameraDirection
                * (1.0 / math.sqrt(cameraDirection:length2()))
        end
    end

    if character.getSmoothViewDirection ~= nil then
        local smoothDirection = character:getSmoothViewDirection()
        if smoothDirection ~= nil and smoothDirection:length2() >= 0.000001 then
            return smoothDirection
                * (1.0 / math.sqrt(smoothDirection:length2()))
        end
    end
    local direction = character.direction
    if direction ~= nil and direction:length2() >= 0.000001 then
        return direction * (1.0 / math.sqrt(direction:length2()))
    end
    return sm.vec3.new(0, 1, 0)
end

local function isFirstPersonView()
    if sm.localPlayer ~= nil
        and sm.localPlayer.isInFirstPersonView ~= nil then
        return sm.localPlayer.isInFirstPersonView()
    end

    if sm.camera == nil then
        return false
    end

    if sm.camera.getCameraState ~= nil and sm.camera.state ~= nil then
        local state = sm.camera.getCameraState()
        if state == sm.camera.state.cutsceneFP
            or state == sm.camera.state.gyroSeatFP then
            return true
        end
        if state == sm.camera.state.cutsceneTP
            or state == sm.camera.state.forcedTP
            or state == sm.camera.state.gyroSeatTP
            or state == sm.camera.state.scriptedTP then
            return false
        end
    end

    -- The default player camera uses pullback step 0 for first person.
    if sm.camera.getCameraPullback ~= nil then
        local pullback = sm.camera.getCameraPullback()
        if type(pullback) == "number" then
            return pullback <= 0
        end
    end
    return false
end

local function getCharacterPosition(character)
    if character.getWorldPosition ~= nil then
        return character:getWorldPosition()
    end
    return character.worldPosition
end

local function destroyEffect(effect)
    if effect ~= nil and sm.exists(effect) then
        pcall(effect.destroy, effect)
    end
end

local function queueToggleSound(self, enabled)
    -- Keep only the newest requested state. In some custom game modes several
    -- no-world callbacks can arrive in a row; retaining every old click makes
    -- ON/OFF sounds play seconds after the corresponding state change.
    self.pendingSound = enabled
        and TOGGLE_ON_EFFECT
        or TOGGLE_OFF_EFFECT
    self.pendingSoundAttempts = 0
    self.pendingSoundErrorLogged = false
end

local function cleanupToggleSounds(self)
    for index = #self.soundEffects, 1, -1 do
        local entry = self.soundEffects[index]
        entry.ticks = entry.ticks + 1
        local remove = entry.effect == nil or not sm.exists(entry.effect)
        if not remove and entry.ticks > 1 and entry.effect.isPlaying ~= nil then
            local ok, playing = pcall(entry.effect.isPlaying, entry.effect)
            remove = ok and not playing
        end
        if not remove and entry.ticks >= TOGGLE_SOUND_LIFETIME_TICKS then
            remove = true
        end
        if remove then
            destroyEffect(entry.effect)
            table.remove(self.soundEffects, index)
        end
    end
end

local function tryPendingToggleSound(self)
    local sound = self.pendingSound
    if sound == nil then return end

    self.pendingSoundAttempts = self.pendingSoundAttempts + 1
    local player = sm.localPlayer.getPlayer()
    local character = player and player.character or nil
    local createdEffect = nil
    local ok, errorText = pcall(function()
        if character == nil or not sm.exists(character)
            or sm.effect == nil or sm.effect.createEffect == nil then
            error("host character or sm.effect.createEffect is missing")
        end

        -- Unlike the world-position form of playEffect, a character-hosted
        -- effect does not require the runtime to manufacture a world position.
        -- This is the same stable path already used by the flashlight itself.
        createdEffect = sm.effect.createEffect(sound, character, HEAD_BONE)
        createdEffect:start()
    end)

    if ok and createdEffect ~= nil then
        self.soundEffects[#self.soundEffects + 1] = {
            effect = createdEffect,
            ticks = 0
        }
        self.pendingSound = nil
        self.pendingSoundAttempts = 0
        self.pendingSoundErrorLogged = false
        trace("sound: " .. sound)
        return
    end

    destroyEffect(createdEffect)

    if not self.pendingSoundErrorLogged then
        self.pendingSoundErrorLogged = true
        trace("hosted sound waiting for character context: " .. tostring(errorText))
    end

    if self.pendingSoundAttempts >= TOGGLE_SOUND_MAX_ATTEMPTS then
        trace("hosted sound dropped before it could become stale: " .. sound)
        self.pendingSound = nil
        self.pendingSoundAttempts = 0
        self.pendingSoundErrorLogged = false
    end
end

local function updateStandingEyeHeight(self, character, firstPerson)
    if self.postureCharacter ~= character then
        self.postureCharacter = character
        self.standingEyeHeight = nil
    end
    if not firstPerson or character:isCrouching()
        or sm.camera == nil or sm.camera.getPosition == nil then
        return
    end

    local cameraPosition = sm.camera.getPosition()
    local characterPosition = getCharacterPosition(character)
    if cameraPosition ~= nil and characterPosition ~= nil then
        self.standingEyeHeight = cameraPosition.z - characterPosition.z
    end
end

local function getCrouchOffset(self, character, firstPerson)
    if not character:isCrouching() then
        return 0.0
    end
    if firstPerson and self.standingEyeHeight ~= nil
        and sm.camera ~= nil and sm.camera.getPosition ~= nil then
        local cameraPosition = sm.camera.getPosition()
        local characterPosition = getCharacterPosition(character)
        if cameraPosition ~= nil and characterPosition ~= nil then
            local currentEyeHeight = cameraPosition.z - characterPosition.z
            return math.min(0.0, currentEyeHeight - self.standingEyeHeight)
        end
    end
    return CROUCH_FALLBACK_OFFSET
end

local function updateHostedAim(self, character)
    if self.effect == nil or not sm.exists(self.effect) then
        return
    end

    local direction = getAimDirection(character)
    local boneRotation = character:getTpBoneRot(HEAD_BONE)
    local inverseBoneRotation = boneRotation:inverse()
    local worldRotation = sm.vec3.getRotation(
        sm.vec3.new(0, 0, 1),
        direction)
    local firstPerson = isFirstPersonView()
    local forwardOffset = firstPerson
        and FIRST_PERSON_FORWARD_OFFSET
        or THIRD_PERSON_FORWARD_OFFSET
    local upOffset = firstPerson
        and FIRST_PERSON_UP_OFFSET
        or THIRD_PERSON_UP_OFFSET
    updateStandingEyeHeight(self, character, firstPerson)
    local crouchOffset = getCrouchOffset(self, character, firstPerson)
    local worldPositionOffset = direction * forwardOffset
        + sm.vec3.new(0, 0, upOffset + crouchOffset)

    -- Never move the spotLight to the camera itself: Scrap Mechanic stops
    -- producing reliable dynamic shadows when the shadow-casting light origin
    -- is almost coincident with the first-person camera. Only the vertical
    -- posture delta is applied; the source remains hosted on jnt_head.

    -- Both values are local to jnt_head. Re-applying the inverse of the
    -- current bone rotation cancels head-animation lag and produces the exact
    -- camera direction in world space. The source itself remains character-
    -- hosted and never follows the third-person camera position.
    self.effect:setOffsetPosition(
        inverseBoneRotation * worldPositionOffset)
    self.effect:setOffsetRotation(inverseBoneRotation * worldRotation)
end

local function createHostedLight(self, character, effectName)
    local effect = sm.effect.createEffect(
        effectName,
        character,
        HEAD_BONE)
    -- Store it immediately so the outer error handler can destroy it if any
    -- of the host/bone setup calls fail in a not-yet-ready world.
    self.effect = effect
    self.effectName = effectName
    self.hostCharacter = character
    self.started = false

    -- Apply the user-editable flashlight tuning before the effect starts.
    applyFlashlightSettings(effect)

    -- The light is attached to the animated head bone. The game moves its
    -- origin together with the character; Lua only aligns the local offsets
    -- with the current camera ray.
    updateHostedAim(self, character)

    trace("hosted effect created: " .. effectName .. " on " .. HEAD_BONE)
end

local function startHostedLight(self, character)
    -- The current Workshop package does not ship a registered
    -- "KeybindBridge - Character Flashlight" effect. Probing it through
    -- sm.effect.createEffect() makes Scrap Mechanic emit an ERROR + LuaVM
    -- ASSERT before we can fall back. HeadLight is the effect that is
    -- actually used successfully, so use it directly in the release build.
    createHostedLight(self, character, FALLBACK_FLASHLIGHT_EFFECT)
    self.effect:start()

    if not self.effect:isPlaying() then
        local failedName = self.effectName or "unknown"
        destroyLight(self)
        error("flashlight effect did not start: " .. failedName)
    end

    self.started = true
    trace("ON: " .. self.effectName)
end

local function updateLightInWorld(self)
    local player = sm.localPlayer.getPlayer()
    local character = player and player.character or nil
    if character == nil or not sm.exists(character) then
        destroyLight(self)
        return
    end

    local locked = character:isSeated()
        or character:getLockingInteractable() ~= nil
    self.blocked = locked
    updateStandingEyeHeight(self, character, isFirstPersonView())
    if locked and self.enabled then
        self.enabled = false
        trace("automatic OFF: character is seated or sleeping")
    end

    if not self.enabled then
        if self.effect ~= nil then
            destroyLight(self)
            trace("OFF")
        end
        return
    end

    -- A respawn or world re-entry replaces the Character userdata. Never keep
    -- an effect hosted to the old character.
    if self.hostCharacter ~= character
        or self.effect == nil
        or not sm.exists(self.effect) then
        destroyLight(self)
        startHostedLight(self, character)
    end

    updateHostedAim(self, character)
end

function flashlight:onCreate()
    self.enabled = false
    self.effect = nil
    self.effectName = nil
    self.hostCharacter = nil
    self.started = false
    self.worldErrorLogged = false
    self.blocked = false
    self.customEffectUnavailable = false
    self.postureCharacter = nil
    self.standingEyeHeight = nil
    self.pendingSound = nil
    self.pendingSoundAttempts = 0
    self.pendingSoundErrorLogged = false
    self.soundEffects = {}
    trace("ready: character-hosted camera-aim spotLight")
end

function flashlight:onDeactivate()
    self.enabled = false
    self.pendingSound = nil
    self.pendingSoundAttempts = 0
    cleanupToggleSounds(self)
    destroyLight(self)
    trace("deactivated: owning content is no longer active")
end

function flashlight:onActionPressed(actionId)
    if actionId ~= "keybindbridge.flashlight.toggle" then
        return
    end

    if self.blocked then
        trace("press ignored while character is seated or sleeping")
        return
    end

    self.enabled = not self.enabled
    trace(self.enabled and "requested ON" or "requested OFF")
    queueToggleSound(self, self.enabled)
end

function flashlight:onUpdate()
    -- The native runtime can observe client callbacks that have no active
    -- world. Keep the requested state and retry after the world becomes valid.
    local ok, errorText = pcall(updateLightInWorld, self)
    if not ok then
        -- A partially created effect must not survive a failed host setup.
        destroyLight(self)
        if not self.worldErrorLogged then
            self.worldErrorLogged = true
            trace("waiting for world context: " .. tostring(errorText))
        end
    else
        self.worldErrorLogged = false
        cleanupToggleSounds(self)
        tryPendingToggleSound(self)
    end
end

KeybindBridgeRuntime.registerExtension(flashlight)
